

package hello.domain;

public class CalcResponse {

	private int result;
	private int variableOne;
	private int variableTwo;
	private String operation;	

    public CalcResponse(int val1, int val2, int res, String method) {
		variableOne = val1;
		variableTwo = val2;
		result = res;
		this.operation = method;
    }

	public int getVariableOne() {
		return variableOne;
	}

	public int getVariableTwo() {
		return variableTwo;
	}

	
    public int getResult() {
        return result;
    }
	
	public String getOperation() {
		return operation;
	}

}