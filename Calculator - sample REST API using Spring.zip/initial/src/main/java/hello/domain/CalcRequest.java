

package hello.domain;

public class CalcRequest {

	int variableOne;
	int variableTwo;

    public CalcRequest() {
    }

	public int getVariableOne() {
		return variableOne;
	}

	public int getVariableTwo() {
		return variableTwo;
	}

	
    public void setVariableOne(int one) {
        variableOne = one;
    }

    public void setVariableTwo(int two) {
        variableTwo = two;
    }

}