

package hello;

public class AdditionResult {

	int result;
	int variableOne;
	int variableTwo;
	
    public AdditionResult(int val1, int val2) {
		variableOne = val1;
		variableTwo = val2;
		result = variableOne + variableTwo;
    }

	public int getVariableOne() {
		return variableOne;
	}

	public int getVariableTwo() {
		return variableTwo;
	}

	
    public int getResult() {
        return result;
    }

}