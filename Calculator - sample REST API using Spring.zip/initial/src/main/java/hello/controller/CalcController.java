package hello.cntroller;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;

import hello.domain.CalcRequest;
import hello.domain.CalcResponse;


@RestController
public class CalcController {

	
	@RequestMapping(method = RequestMethod.POST, path = "/add")
	public CalcResponse add (@RequestBody CalcRequest req) {
		
		int variable1 = req.getVariableOne();
		int variable2 = req.getVariableTwo();
		return new CalcResponse (variable1, variable2, variable2 + variable1, "Addition");
		
	}
	
	@RequestMapping(method = RequestMethod.POST, path = "/subtract")
	public CalcResponse sub (@RequestBody CalcRequest req) {
		
		int variable1 = req.getVariableOne();
		int variable2 = req.getVariableTwo();
		return new CalcResponse (variable1, variable2, variable2 - variable1, "Subtraction");
		
	}

	
	
}